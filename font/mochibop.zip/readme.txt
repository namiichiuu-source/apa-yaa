This demo font is for PERSONAL USE ONLY. You may:

* Use this font in personal projects (e.g. schoolwork, personal crafts, social media posts, etc.)
* Share the demo link, as long as credit is given

You may NOT:

* Use it for commercial projects (client work, logos, products for sale, ads, merch, etc.)
* Modify, redistribute, or sell the font file
* Use it in apps, games, or websites (even free ones)

This demo includes basic letters, numbers, and limited punctuation only.
To access the full set with multilingual support, alternates, and extra glyphs, please purchase the complete version at https://payhip.com/b/BiV9Q

Thanks for supporting independent artists! 💖

